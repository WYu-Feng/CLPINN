#!/usr/bin/env python


from typing import Tuple
import argparse

from src.loadopts import *
from src.utils import timemeter
from src.config import DEVICE
import copy
import torch.nn as nn
import torch
import numpy as np

METHOD = "Equation"
SAVE_FREQ = 5
FMT = "{description}={act}={leverage}-{eps}-{nums}" \
        "={learning_policy}-{optimizer}-{lr}" \
        "={epochs}-{trigger}" \
        "={batch_size}={transform}"

parser = argparse.ArgumentParser()
parser.add_argument("--model", type=str, default='linear')
parser.add_argument("--dataset", type=str, default='shockwave')
parser.add_argument("--info_path", type=str, default=None)

# for the shockwave dataset
parser.add_argument("--eps", type=float, default=1e-9)
parser.add_argument("--nums", type=int, default=30000)
parser.add_argument("--nums-valid", type=int ,default=30000)
parser.add_argument("--nums-test", type=int, default=30000, help="nums")

# for expnet
parser.add_argument("--dim-latent", type=int, default=20)
parser.add_argument("--act", type=str, default='relu')

# for regularization
parser.add_argument("--leverage", type=float, default=1.)

# basic settings
parser.add_argument("--loss", type=str, default="mse_loss")
parser.add_argument("--optimizer", type=str, choices=("sgd", "adam"), default="adam")
parser.add_argument("--trigger", type=int, default=999999)
parser.add_argument("-mom", "--momentum", type=float, default=0.9,
                help="the momentum used for SGD")
parser.add_argument("-beta1", "--beta1", type=float, default=0.9,
                help="the first beta argument for Adam")
parser.add_argument("-beta2", "--beta2", type=float, default=0.999,
                help="the second beta argument for Adam")
parser.add_argument("-wd", "--weight_decay", type=float, default=0.,
                help="weight decay")
parser.add_argument("-lr", "--lr", "--LR", "--learning_rate", type=float, default=0.01)
parser.add_argument("-lp", "--learning_policy", type=str, default="null", 
                help="learning rate schedule defined in config.py")
parser.add_argument("--epochs", type=int, default=50000)
parser.add_argument("-b", "--batch_size", type=int, default=2000)
parser.add_argument("--transform", type=str, default='default', 
                help="the data augmentations which will be applied during training.")


# eval
parser.add_argument("--eval-train", action="store_true", default=False)
parser.add_argument("--eval-valid", action="store_false", default=True)
parser.add_argument("--eval-freq", type=int, default=100,
                help="for valid dataset only")

parser.add_argument("--resume", action="store_true", default=False)
parser.add_argument("--progress", action="store_true", default=False, 
                help="show the progress if true")
parser.add_argument("--log2file", action="store_false", default=True,
                help="False: remove file handler")
parser.add_argument("--log2console", action="store_false", default=True,
                help="False: remove console handler if log2file is True ...")
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--benchmark", action="store_true", default=False)
parser.add_argument("-m", "--description", type=str, default=METHOD)
opts = parser.parse_args()
opts.description = FMT.format(**opts.__dict__)



def oracle(x, y, g1, g2, eps=opts.eps):
    return -eps * g2  - (2 - x) * g1 + y


@timemeter("Setup")
def load_cfg() -> Tuple[Config, str]:
    from src.dict2obj import Config
    from src.base import Coach
    from src.utils import set_seed, activate_benchmark, load_checkpoint, set_logger, load
    from models.base import EquArch

    cfg = Config()

    # generate the path for logging information and saving parameters
    cfg['info_path'], cfg['log_path'] = generate_path(
        method=METHOD, dataset_type=opts.dataset, 
        model=opts.model, description=opts.description
    )
    # set logger
    logger = set_logger(
        path=cfg.log_path, 
        log2file=opts.log2file, 
        log2console=opts.log2console
    )

    activate_benchmark(opts.benchmark)
    set_seed(opts.seed)

    # the model and other settings for training
    model = load_model(opts.model)(
        latent_features=opts.dim_latent,
        activation=opts.act
    )
    model = EquArch(model=model)
    # load(model, '')
    
    if opts.info_path is not None:
        load(
            model, opts.info_path
        )

    # load the optimizer and learning_policy
    first_optimizer = load_optimizer(
        model=model, optim_type=opts.optimizer, lr=opts.lr,
        momentum=opts.momentum, betas=(opts.beta1, opts.beta2),
        weight_decay=opts.weight_decay
    )
    torch.optim.lr_scheduler.StepLR(first_optimizer, 6000 * 15, gamma=0.5, last_epoch=-1)
    
    second_optimizer = load_optimizer(
        model=model, optim_type='prop'
    )

    learning_policy = load_learning_policy(
        optimizer=first_optimizer, 
        learning_policy_type=opts.learning_policy,
        T_max=opts.epochs
    )

    if opts.resume:
        cfg['start_epoch'] = load_checkpoint(
            path=cfg.info_path, model=model, 
            first_optimizer=first_optimizer, 
            second_optimizer=second_optimizer,
            lr_scheduler=learning_policy
        )
    else:
        cfg['start_epoch'] = 0

    cfg['coach'] = Coach(
        model=model,
        loss_func=load_loss_func(opts.loss), 
        oracle=oracle,
        first_optimizer=first_optimizer,
        second_optimizer=second_optimizer,
        learning_policy=learning_policy
    )

    return cfg


def preparation(coach):
    from src.utils import TrackMeter, ImageMeter, getLogger
    from src.dict2obj import Config
    logger = getLogger()
    loss_logger = Config(
        train=TrackMeter("Train"),
        valid=TrackMeter("Valid")
    )

    loss_logger.plotter = ImageMeter(*loss_logger.values(), title="Loss")

    @timemeter("Evaluation")
    def evaluate(dataloader, prefix='Valid', epoch=8888):
        loss = coach.evaluate(dataloader)
        logger.info(f"{prefix} >>> [Loss: {loss:.6f}]")
        getattr(loss_logger, prefix.lower())(data=loss, T=epoch)
        return loss
    return loss_logger, evaluate


def visual(
        model, validloader,
        info_path, log_path,
        device=DEVICE, epoch=8888
):
    import os
    from src.utils import AverageMeter
    from src.loss_zoo import mse_loss
    import matplotlib.pyplot as plt

    if not os.path.exists('result save'):
        os.makedirs('result save')

    loss_function = nn.L1Loss(reduction='none')
    model.eval()
    pred_list = []
    target_list = []
    x_list = []
    loss_list = []
    for x, y, g1, g2 in validloader:
        x = x.to(device)
        y = y.to(device)
        g1 = g1.to(device)
        g2 = g2.to(device)

        x.requires_grad_(True)
        y_pred = model(x)
        loss = loss_function(y_pred, y)

        pred_list.extend([a.detach().cpu().numpy() for a in y_pred])
        target_list.extend([a.detach().cpu().numpy() for a in y])
        x_list.extend([a.detach().cpu().numpy() for a in x])
        loss_list.extend([a.detach().cpu().numpy() for a in loss])

    plt.plot(x_list, target_list, markeredgecolor='r', markerfacecolor='r', linewidth=3, label='Exact solution')
    plt.plot(x_list, pred_list, markeredgecolor='k', markerfacecolor='k', linewidth=3, label='Exact solution')
    plt.savefig('./result save/epoch {:} result.png'.format(epoch), dpi=300)
        
    

def test_loss(model, testloader):
    model.eval()
    
    def mre(y_pred, y_true):
        return torch.mean(torch.abs(y_true - y_pred) / (torch.abs(y_true) + 1e-6))

    mse_function = nn.MSELoss(reduction='mean')
    l1_function = nn.L1Loss(reduction='mean')
    
    ave_mse_loss = 0
    ave_l1_loss = 0
    ave_mre_loss = 0
    for idx, (x, y, g1, g2) in enumerate(testloader):
        x = x.cuda()
        y = y.cuda()
        y_pred = model(x)
        
        ave_mse_loss += mse_function(y_pred, y)
        ave_l1_loss += l1_function(y_pred, y)
        ave_mre_loss += mre(y_pred, y)
        
    ave_mse_loss = ave_mse_loss / (idx + 1)
    ave_l1_loss = ave_l1_loss / (idx + 1)
    ave_mre_loss = ave_mre_loss / (idx + 1)
    
    return ave_mse_loss, ave_l1_loss, ave_mre_loss

@timemeter("Main")
def main(
    coach,
    start_epoch, 
    info_path, log_path
):  

    from src.utils import save_checkpoint
    
    # preparation
    loss_logger, evaluate = preparation(coach)
    
    testset = load_dataset(
        dataset_type=opts.dataset,
        transforms=opts.transform,
        eps=opts.eps,
        num_samples = opts.nums_test,
        train=False
    )
    
    trainloader = load_dataloader(
        dataset=testset,
        batch_size=opts.batch_size,
        train=True,
        show_progress=opts.progress
    )

    testloader = load_dataloader(
        dataset=testset,
        batch_size = opts.nums_test,
        train=False,
        show_progress=opts.progress
    )
    
    boundary = testset.data.boundary

    for epoch in range(start_epoch, opts.epochs):
        if epoch % 10 == 0:
            mse_loss, mae_loss, mre_loss = test_loss(coach.model, testloader)
                
        running_loss = coach.train(trainloader, boundary, leverage=opts.leverage, epoch=epoch, opts = opts)
        
        if (epoch + 1) % 100 == 0:
            mse_loss, mae_loss, mre_loss = test_loss(coach.model, testloader)
            with open('log_loss.txt', 'a') as f:
                f.write('epoch:{:} mse:{:} mae:{:} mre:{:}'.formatepoch, (mse_loss.cpu().detach().numpy(), mae_loss.cpu().detach().numpy(), mre_loss.cpu().detach().numpy()))
                f.write('\n')  
    
        if (epoch + 1) % 1000 == 0:
            visual(coach.model, testloader, info_path, log_path, coach.device, epoch)  
            coach.save(info_path, epoch)


if __name__ ==  "__main__":
    from src.utils import readme
    
    cfg = load_cfg()
    opts.log_path = cfg.log_path
    readme(cfg.info_path, opts)
    readme(cfg.log_path, opts, mode="a")

    main(**cfg)

