

import torch
import torch.nn as nn
from .layerops import ExpLinear, Sin, Wang


class LinearNet(nn.Module):

    def __init__(
        self, 
        in_features: int = 1,
        latent_features: int = 20,
        activation: str = 'sin'
    ) -> None:
        super().__init__()

        if activation == "tanh":
            self.act = nn.Tanh()
        elif activation == "relu":
            self.act = nn.ReLU(True)
        elif activation == "sin":
            self.act = Sin()
        elif activation == 'wang':
            self.act = Wang()
        else:
            raise ValueError("No such activation ...")
        self.sigmoid = nn.Sigmoid()
        tanh = nn.Tanh()
        self.relu = nn.ReLU(True)
        
        self.w = nn.Parameter(torch.Tensor([1]))
        
        self.dense = nn.Sequential(
            nn.Linear(in_features, latent_features),
            tanh,
            nn.Linear(latent_features, latent_features),
            tanh,
            nn.Linear(latent_features, 1)
        )

    def forward(self, x):
        return self.dense(x)
    
    def get_fea(self, x):
        fea = self.relu(self.fc1(x))
        fea = nn.functional.normalize(fea, dim=1, p=2)
        return fea

    
    
class TNet(nn.Module):

    def __init__(
        self, 
        in_features: int = 1,
        latent_features: int = 20,
        activation: str = 'sin'
    ):
        super().__init__()

        if activation == "tanh":
            self.act = nn.Tanh()
        elif activation == "relu":
            self.act = nn.ReLU(True)
        elif activation == "sin":
            self.act = Sin()
        else:
            raise ValueError("No such activation ...")
        sigmoid = nn.Sigmoid()
        tanh = nn.Tanh()
        relu = nn.ReLU(True)
        
        self.dense = nn.Sequential(
            nn.Linear(401, 100),
            tanh,
            nn.Linear(100, 50),
            tanh,
            nn.Linear(50, 1)
        )

    def forward(self, a, b, x):
        return self.dense(torch.cat((a, b, x), dim = 0))