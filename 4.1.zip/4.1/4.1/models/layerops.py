
import torch
import torch.nn as nn
import torch.nn.functional as F



class ExpLinear(nn.Linear):

    def forward(self, input):
        return F.linear(input, self.weight.exp(), self.bias)

class Sin(nn.Module):

    def forward(self, x):
        return torch.sin(x)


class Wang(nn.Module):
    def __init__(self):
        super(Wang, self).__init__()

    def forward(self, x):
        return torch.where(x>0, x**2, -(x**2))

