from typing import Callable, Dict, Iterable
import torch
import torch.nn as nn
import os

from .utils import AverageMeter, ProgressMeter, timemeter, getLogger
from .loss_zoo import mse_loss
from .config import DEVICE, SAVED_FILENAME, PRE_BEST
import numpy as np
import sklearn.cluster as skc
from models.LinearNet import TNet
import copy
from torch.autograd import gradcheck


class Coach:
    
    def __init__(
        self, model: nn.Module,
        loss_func: Callable, 
        oracle: Callable,
        first_optimizer: torch.optim.Optimizer, 
        second_optimizer: torch.optim.Optimizer, 
        learning_policy: "learning rate policy",
        device: torch.device = DEVICE,
    ):
        self.model = model
        # for param in self.model.parameters():
        #     self.nguyen_widrow_init(param.weight, param.bias)
            
        self.device = device
        self.loss_func = loss_func
        self.oracle = oracle
        self.first_optimizer = first_optimizer
        self.second_optimizer = second_optimizer
        self.learning_policy = learning_policy
        self.loss = AverageMeter("Loss")
        self.progress = ProgressMeter(self.loss)
        self.H = TNet().cuda()
        self.t_optim = torch.optim.Adam(self.H.parameters(), lr=0.1, betas=(0.9, 0.999), weight_decay=0.)
        
        self._best = float('inf')

        
    def nguyen_widrow_init(weight, bias, scale = 1):
        out_channels, in_channels = weight.size()
        nn.init.uniform(weight, -0.5, 0.5)
        scale = scale * out_channels ** (1 / in_channels)
        weight.data.copy_(scale * F.normalize(weight.data, p = 1, dim = 1))
        nn.init.uniform_(bias, -scale, scale)
    
    
    def save_best(self, mse: float, path: str, prefix: str = PRE_BEST):
        if mse < self._best:
            self._best = mse
            self.save(path, '_'.join((prefix, SAVED_FILENAME)))
            return 1
        else:
            return 0

    def check_best(
        self, mse: float,
        path: str, epoch: int = 8888
    ):
        logger = getLogger()
        if self.save_best(mse, path):
            logger.debug(f"[Coach] Saving the best nat ({mse:.6f}) model at epoch [{epoch}]")
        
    def save(self, path, epoch):
        torch.save(self.model.state_dict(), os.path.join(path, '{:}_'.format(epoch) + SAVED_FILENAME))
    
    
    @timemeter("Train/Epoch")
    def train(self, trainloader, boundary, leverage, opts, epoch = 8888):
        self.progress.step() # reset the meter
        self.model.train()
        bx, by, bg1, bg2 = boundary['x'], boundary['y'], boundary['g1'], boundary['g2']

        loss_function = nn.MSELoss(reduction='none')
        optimizer = self.first_optimizer
        
        for i, (x, y, g1, g2) in enumerate(trainloader):
            x = x.to(self.device)
            y = y.to(self.device)
            g1 = g1.to(self.device)
            g2 = g2.to(self.device)
            bx = bx.to(self.device)
            by = by.to(self.device)
            
            target = self.oracle(x, y, g1, g2)
            x.requires_grad_(True)
            y_pred = self.model(x)
            g1_pred = torch.autograd.grad(
                y_pred, x, 
                grad_outputs=torch.ones_like(y_pred),
                create_graph=True
            )[0]
            g2_pred = torch.autograd.grad(
            g1_pred, x, 
            grad_outputs=torch.ones_like(g1_pred),
            create_graph=True
            )[0]
            x.requires_grad_(False)
            pred = self.oracle(x, y_pred, g1_pred, g2_pred)
            loss = self.loss_func(pred, target)
            
            by_pred = self.model(bx)[0]
            bloss = self.loss_func(by_pred, by)
            loss = loss + bloss * leverage
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    
    @timemeter("Evaluation")
    def evaluate(self, validloader: Iterable, *, epoch: int = 8888):

        self.progress.step() # reset the meter
        self.model.eval()
        for x, y, g1, g2 in validloader:
            x = x.to(self.device)
            y = y.to(self.device)
            g1 = g1.to(self.device)
            g2 = g2.to(self.device)

            target = self.oracle(x, y, g1, g2)
            x.requires_grad_(True)
            y_pred = self.model(x)
            g1_pred = torch.autograd.grad(
                y_pred, x, 
                grad_outputs=torch.ones_like(y_pred),
                create_graph=True
            )[0]
            g2_pred = torch.autograd.grad(
               g1_pred, x, 
               grad_outputs=torch.ones_like(g1_pred),
               retain_graph=False
            )[0]
            x.requires_grad_(False)
            pred = self.oracle(x, y_pred, g1_pred, g2_pred)
            loss = self.loss_func(pred, target)

            self.loss.update(loss.item(), x.size(0), mode="mean")

        return self.loss.avg