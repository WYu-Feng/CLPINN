


import torch
import torch.nn.functional as F



x = torch.rand(4, 3, 2, 2)

y = F.interpolate(x, scale_factor=2, mode='bilinear')
print(y.size())
