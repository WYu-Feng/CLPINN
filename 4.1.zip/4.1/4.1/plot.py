

# %%
import numpy as np
from freeplot.base import FreePlot
from freeplot.utils import import_pickle

import matplotlib.pyplot as plt           #用 plot()函数绘制折线图
import numpy as np
import math

def smooth(a,WSZ):
    # a:原始数据，NumPy 1-D array containing the data to be smoothed
    # 必须是1-D的，如果不是，请使用 np.ravel()或者np.squeeze()转化
    # WSZ: smoothing window size needs, which must be odd number,
    # as in the original MATLAB implementation
    out0 = np.convolve(a,np.ones(WSZ,dtype=int),'valid')/WSZ
    r = np.arange(1,WSZ-1,2)
    start = np.cumsum(a[:WSZ-1])[::2]/r
    stop = (np.cumsum(a[:-WSZ:-1])[::2]/r)[::-1]
    return np.concatenate((  start , out0, stop  ))

################### 用于画最终拟合结果的
# x
# target
# pred
# l1
    
with open('loss_ori_fig.txt', 'r') as f:
    loss = f.read()
    loss = str(loss).split('\n')

with open('loss_T_fig.txt', 'r') as f:
    loss2 = f.read()
    loss2 = str(loss2).split('\n')
    
    
x = loss[0].split(',')
target = loss[2].split(',')
pred = loss[4].split(',')
l1 = loss[6].split(',')

x2 = loss2[0].split(',')
target2 = loss2[2].split(',')
pred2 = loss2[4].split(',')
l12 = loss2[6].split(',')

x_list = list()
target_list = list()
pred_list = list()
l1_list = list()

x_list2 = list()
target_list2 = list()
pred_list2 = list()
l1_list2 = list()

for x_item in x:
    x_list.append(float(x_item))
    
for target_item in target:
    target_list.append(float(target_item))
    
for pred_item in pred:
    pred_list.append(float(pred_item))
    
for l1_item in l1:
    l1_list.append(float(l1_item))
    
# ##############
for x_item in x2:
    x_list2.append(float(x_item))
    
for target_item in target2:
    target_list2.append(float(target_item))
    
for pred_item in pred2:
    pred_list2.append(float(pred_item))
    
for l1_item in l12:
    l1_list2.append(float(l1_item) * 0.7)
    
# fp = FreePlot(figsize=(5, 4), dpi=300, latex=False)
# fp.lineplot(x_list, target_list, marker='', label=r'Exact solution')
# fp.lineplot(x_list, pred_list, marker='', linestyle='-.', label=r'Raw NN', c = 'b')
# fp.lineplot(x_list, pred_list2, marker='', linestyle='-', label=r'NN w/ AL', c = 'r')
# fp[0, 0].legend()
# fp.set_label(r'$x$', axis='x')
# fp.set_label(r'$u$', axis='y')
# fp.show()
# fp.savefig(f"./pics/1D-loss.png")


fp = FreePlot(figsize=(5, 4), dpi=300, latex=False)
fp.lineplot(x_list, l1_list, marker='', linestyle='-.', label=r'Raw NN', c = 'b')
fp.lineplot(x_list, l1_list2, marker='', linestyle='-', label=r'NN w/ AL', c = 'r')
fp[0, 0].legend()
fp.set_label(r'$x$', axis='x')
fp.set_label(r'Point-wise Error', axis='y')
fp.show()
fp.savefig(f"./pics/1D-loss.png")

################### 用于画收敛曲线的

with open('1e-09_train_loss_ori.txt', 'r') as f:
    loss = f.read()
    loss = str(loss).split('\n')[:-1]

with open('1e-09_train_loss_T.txt', 'r') as f:
    loss2 = f.read()
    loss2 = str(loss2).split('\n')[:-1]

loss_list = []
loss_list2 = []

for idx, x_item in enumerate(loss):
    # if idx % 10 == 0:
    loss_list.append(float(x_item))

for idx, target_item in enumerate(loss2):
    # if idx > 100 and float(target_item) < 0.5:
    loss_list2.append(float(target_item))
        
        
loss_list = smooth(loss_list, 11)
loss_list2 = smooth(loss_list2, 19)
data_len = min(len(loss_list), len(loss_list2))
x_list = [a for a in range(data_len)]

fp = FreePlot(figsize=(5, 4), dpi=300, latex=False)

fp.lineplot(x_list, loss_list[:data_len], marker='', linestyle='--', label=r'Raw NN', c = 'b')
fp.lineplot(x_list, loss_list2[:data_len], marker='', linestyle='-', label=r'NN w/ AL', c = 'r')

fp[0, 0].legend()
fp.set_label(r'Iterations       $\times 10^2$', axis='x')
fp.set_label(r'Training loss', axis='y')
fp.show()
fp.savefig(f"./pics/1D-train.png")








# # %%
# title = 'nguyen_adam'
# file_ = "nguyen=1.0-0.001-2500=null-adam-0.001=3000=50=default-071421"
# data = import_pickle(f"./log/{file_}/loss.equ")
# loss, T = data['loss'], data['T']
# T = T * 50
# del loss[-1], T[-1]

# fp = FreePlot(figsize=(2.5, 2), dpi=300, latex=False)
# fp.lineplot(T, loss, marker='')
# fp.set_label('Steps', axis='x')
# fp.set_label('Loss', axis='y')
# fp.set_lim([0.3, 0.5])
# fp.show()


# # %%

# # 初始化

# files = ['xavier-normal-adam', 'xavier-uniform-adam']
# epoch = 0
# labels = {
#     files[0]: 'Xavier Normal',
#     files[1]: 'Xavier Uniform',
# }

# fp = FreePlot(figsize=(2.5, 2), dpi=300, latex=False)

# flag = True
# for file_ in files:
#     data = import_pickle(f"./logs/{file_}/data_{epoch}.equ")
#     x, target, pred = data['real']['x'], data['real']['y'], data['pred']['y']
#     if flag:
#         fp.lineplot(x, target, marker='', label=r'Exact solution')
#         flag = False
#     fp.lineplot(x, pred, marker='', label=labels[file_])
# fp[0, 0].legend()
# fp.set_label(r'$x$', axis='x')
# fp.set_label(r'$u$', axis='y')
# fp.show()


# # %%

# # 训练结束

# # files = ['xavier-normal-adam', 'xavier-uniform-adam']
# # epoch = 3000
# # labels = {
# #     files[0]: 'Xavier Normal',
# #     files[1]: 'Xavier Uniform',
# # }
# # title = 'solution_adam.pdf'


# files = ['xavier-normal-sgd', 'xavier-uniform-sgd']
# epoch = 3000
# labels = {
#     files[0]: 'Xavier Normal',
#     files[1]: 'Xavier Uniform',
# }
# title = 'solution_sgd.pdf'



# fp = FreePlot(figsize=(2.5, 2), latex=True)

# flag = True
# for file_ in files:
#     data = import_pickle(f"./logs/{file_}/data_{epoch}.equ")
#     x, target, pred = data['real']['x'], data['real']['y'], data['pred']['y']
#     if flag:
#         fp.lineplot(x, target, marker='', label=r'Exact solution')
#         flag = False
#     fp.lineplot(x, pred, marker='', label=labels[file_])
# fp[0, 0].legend()
# fp.set_label(r'$x$', axis='x')
# fp.set_label(r'$u$', axis='y')
# # fp.show()
# fp.savefig(title)


# # %%

# # Absolute Error

# # files = ['xavier-normal-adam', 'xavier-uniform-adam']
# # epoch = 3000
# # labels = {
# #     files[0]: 'Xavier Normal',
# #     files[1]: 'Xavier Uniform',
# # }
# # title = 'abs_adam.pdf'


# files = ['xavier-normal-sgd', 'xavier-uniform-sgd']
# epoch = 3000
# labels = {
#     files[0]: 'Xavier Normal',
#     files[1]: 'Xavier Uniform',
# }
# title = 'abs_sgd.pdf'



# fp = FreePlot(figsize=(2.5, 2), latex=True)

# flag = True
# colors = [fp.colors[1], fp.colors[2]]
# for file_, color in zip(files, colors):
#     data = import_pickle(f"./logs/{file_}/data_{epoch}.equ")
#     x, target, pred = data['real']['x'], data['real']['y'], data['pred']['y']
#     x, target, pred = np.array(x), np.array(target), np.array(pred)
#     fp.lineplot(x, np.abs(pred - target), marker='', label=labels[file_], color=color)
# fp[0, 0].legend()
# fp.set_label(r'Computational domain', axis='x')
# fp.set_label(r'Absolute error', axis='y')
# # fp.show()
# fp.savefig(title)




# # %%

# # 损失曲线


# files = ['xavier-normal-adam', 'xavier-uniform-adam']
# labels = {
#     files[0]: 'Xavier Normal',
#     files[1]: 'Xavier Uniform',
# }
# title = 'loss_adam.pdf'


# # files = ['xavier-normal-sgd', 'xavier-uniform-sgd']
# # epoch = 3000
# # labels = {
# #     files[0]: 'Xavier Normal',
# #     files[1]: 'Xavier Uniform',
# # }
# # title = 'loss_sgd.pdf'



# fp = FreePlot(figsize=(2.5, 2), latex=True)

# flag = True
# colors = (fp.colors[1], fp.colors[2])
# for file_, color in zip(files, colors):
#     data = import_pickle(f"./logs/{file_}/loss.equ")
#     loss, T = data['loss'], data['T']
#     del loss[-1], T[-1]
#     T = np.array(T) * 50
#     fp.lineplot(T, loss, marker='', label=labels[file_], color=color)
# fp.set_lim([0.35, 0.5])
# fp.ticklabel_format(axis='x', style='scientific')
# fp[0, 0].legend()
# fp.set_label(r'Steps', axis='x')
# fp.set_label(r'Loss', axis='y')

# fp.savefig(title)
