

# %%
import torch

# %%
x = torch.rand((10, 2)).round()
x, y = x[:, 0], x[:, 1]
torch.where((y == 0) | ((x == 0) & (y < 1 / 5)), torch.ones_like(x), torch.zeros_like(x))

# %%