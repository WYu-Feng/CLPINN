#!/usr/bin/env python


from typing import Tuple
import argparse

from src.loadopts import *
from src.utils import timemeter
from src.config import DEVICE



METHOD = "Equation"
SAVE_FREQ = 5
FMT = "{description}={loss}-{eps}"

parser = argparse.ArgumentParser()
parser.add_argument("--model", type=str, default='linear')
parser.add_argument("--dataset", type=str, default='shockwave')
parser.add_argument("--info_path", type=str, default=None)

# for the shockwave dataset
parser.add_argument("--eps", type=float, default=1e-3)
parser.add_argument("--nums", type=int, default=1000 * 1000)
parser.add_argument("--nums-valid", type=int, default=100, help="nums ** 2")
parser.add_argument("--nums-boundary", type=int, default=10000)


# for expnet
parser.add_argument("--dim-latent", type=int, default=20)

# for regularization
parser.add_argument("--leverage", type=float, default=1.)

# basic settings
parser.add_argument("--loss", type=str, default="identity", choices=("identity", "tanh", "log", "refine"))
parser.add_argument("--optimizer", type=str, choices=("sgd", "adam"), default="adam")
parser.add_argument("-mom", "--momentum", type=float, default=0.9,
                help="the momentum used for SGD")
parser.add_argument("-beta1", "--beta1", type=float, default=0.9,
                help="the first beta argument for Adam")
parser.add_argument("-beta2", "--beta2", type=float, default=0.999,
                help="the second beta argument for Adam")
parser.add_argument("-wd", "--weight_decay", type=float, default=0.,
                help="weight decay")
parser.add_argument("-lr", "--lr", "--LR", "--learning_rate", type=float, default=0.001)
parser.add_argument("-lp", "--learning_policy", type=str, default="null", 
                help="learning rate schedule defined in config.py")
parser.add_argument("--epochs", type=int, default=1000)
parser.add_argument("-b", "--batch_size", type=int, default=1000)
parser.add_argument("--transform", type=str, default='default', 
                help="the data augmentations which will be applied during training.")


# eval
parser.add_argument("--eval-train", action="store_true", default=False)
parser.add_argument("--eval-valid", action="store_false", default=True)
parser.add_argument("--eval-freq", type=int, default=100,
                help="for valid dataset only")

parser.add_argument("--resume", action="store_true", default=False)
parser.add_argument("--progress", action="store_true", default=False, 
                help="show the progress if true")
parser.add_argument("--log2file", action="store_false", default=True,
                help="False: remove file handler")
parser.add_argument("--log2console", action="store_false", default=True,
                help="False: remove console handler if log2file is True ...")
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--benchmark", action="store_true", default=False)
parser.add_argument("-m", "--description", type=str, default=METHOD)
opts = parser.parse_args()
opts.description = FMT.format(**opts.__dict__)


import torch
import numpy as np
import math
from scipy.stats import uniform


def equ(x, u, ux, uy, uxx, uyy, eps=opts.eps):
    return -eps * (uxx + uyy) + 0.5 * ux + math.sqrt(3) * uy / 2

def sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    x = uniform.rvs(loc=bounds[0], scale=bounds[1] - bounds[0], size=nums).astype(np.float32)
    y = uniform.rvs(loc=bounds[0], scale=bounds[1] - bounds[0], size=nums).astype(np.float32)
    x, y = torch.from_numpy(x), torch.from_numpy(y)
    return torch.stack([x, y], dim=1)

def valid_sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    meta = torch.linspace(bounds[0], bounds[1], steps=nums)
    X, Y = torch.meshgrid(meta, meta)
    return X, Y

def bd_sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    return sampling_fn(nums, bounds).round()

def collect_fn(data: torch.Tensor): # not for dataloader
    return [data]



@timemeter("Setup")
def load_cfg() -> Tuple[Config, str]:
    from src.dict2obj import Config
    from src.base import Coach
    from src.utils import set_seed, activate_benchmark, load_checkpoint, set_logger, load
    from models.base import EquArch

    cfg = Config()
    
    # generate the path for logging information and saving parameters
    cfg['info_path'], cfg['log_path'] = generate_path(
        method=METHOD, dataset_type=opts.dataset, 
        model=opts.model, description=opts.description
    )
    # set logger
    logger = set_logger(
        path=cfg.log_path, 
        log2file=opts.log2file, 
        log2console=opts.log2console
    )

    activate_benchmark(opts.benchmark)
    set_seed(opts.seed)

    # the model and other settings for training
    model = load_model(opts.model)(
        latent_features=opts.dim_latent
    )
    model = EquArch(model=model)

    if opts.info_path is not None:
        load(
            model, opts.info_path
        )

    # load the dataset
    trainset = load_dataset(
        dataset_type=opts.dataset,
        sampling_fn=sampling_fn,
        collect_fn=collect_fn,
        num_samples=opts.nums,
        transforms=opts.transform,
        train=True
    )
    validset = load_dataset(
        dataset_type=opts.dataset,
        sampling_fn=valid_sampling_fn,
        collect_fn=collect_fn,
        num_samples=opts.nums_valid,
        train=False
    )
    cfg['trainloader'] = load_dataloader(
        dataset=trainset,
        batch_size=opts.batch_size,
        train=True,
        show_progress=opts.progress
    )
    cfg['validloader'] = load_dataloader(
        dataset=validset,
        batch_size=opts.batch_size,
        train=False,
        show_progress=opts.progress
    )
    def boundary():
        data = bd_sampling_fn(opts.nums_boundary)
        while True:
            indices = torch.randint(0, opts.nums_boundary, (opts.batch_size, ))
            yield data[indices]

    cfg['boundary'] = boundary()

    # load the optimizer and learning_policy
    optimizer = load_optimizer(
        model=model, optim_type=opts.optimizer, lr=opts.lr,
        momentum=opts.momentum, betas=(opts.beta1, opts.beta2),
        weight_decay=opts.weight_decay
    )
    learning_policy = load_learning_policy(
        optimizer=optimizer, 
        learning_policy_type=opts.learning_policy,
        T_max=opts.epochs
    )

    if opts.resume:
        cfg['start_epoch'] = load_checkpoint(
            path=cfg.info_path, model=model, 
            optimizer=optimizer, 
            lr_scheduler=learning_policy
        )
    else:
        cfg['start_epoch'] = 0

    cfg['coach'] = Coach(
        model=model,
        loss_func=load_loss_func(opts.loss),
        equ=equ,
        optimizer=optimizer,
        learning_policy=learning_policy
    )

    return cfg


def preparation(coach):
    from src.utils import TrackMeter, ImageMeter, getLogger
    from src.dict2obj import Config
    logger = getLogger()
    loss_logger = Config(
        train=TrackMeter("Train"),
        valid=TrackMeter("Valid")
    )

    loss_logger.plotter = ImageMeter(*loss_logger.values(), title="Loss")

    @timemeter("Evaluation")
    def evaluate(dataloader, prefix='Valid', epoch=8888):
        loss = coach.evaluate(dataloader)
        logger.info(f"{prefix} >>> [Loss: {loss:.6f}]")
        getattr(loss_logger, prefix.lower())(data=loss, T=epoch)
        return loss
    return loss_logger, evaluate



@timemeter("visual")
@torch.no_grad()
def visual(
    model, validloader, 
    info_path, log_path,
    device=DEVICE, epoch=8888
):
    import os
    import numpy as np
    from freeplot.base import FreePlot
    
    model.eval()
    running_results = {
        'x':[], 'pred': []
    }


    for data in validloader:
        x = data[0].to(device)
        u_pred = model(x)
        running_results['x'].append(x.clone().cpu())
        running_results['pred'].append(u_pred.clone().cpu())
    
    for key, value in running_results.items():
        running_results[key] = torch.cat(value, dim=0).numpy()


    X = running_results['x'][:, 0]
    Y = running_results['x'][:, 1]
    X = X.reshape((opts.nums_valid, opts.nums_valid))
    Y = Y.reshape((opts.nums_valid, opts.nums_valid))
    return X, Y, running_results['pred'] 




@timemeter("Main")
def main(
    coach,
    trainloader, validloader, boundary,
    start_epoch, 
    info_path, log_path
):  

    import os
    from src.utils import save_checkpoint
    from freeplot.utils import export_pickle

    # preparation
    loss_logger, evaluate = preparation(coach)

    best = float('inf')
    for epoch in range(start_epoch, opts.epochs):

        if epoch % SAVE_FREQ == 0:
            save_checkpoint(info_path, coach.model, coach.optimizer, coach.learning_policy, epoch)

        if epoch % opts.eval_freq == 0:
            # if opts.eval_train:
            #     evaluate(trainloader, prefix='Train', epoch=epoch)
            if opts.eval_valid:
                X, Y, preds = visual(coach.model, validloader, info_path, log_path, coach.device, epoch)

                loss = evaluate(validloader, prefix="Valid", epoch=epoch)
                coach.check_best(loss, info_path, epoch=epoch)

        running_loss = coach.train(trainloader, boundary, leverage=opts.leverage, epoch=epoch)
        loss_logger.train(data=running_loss, T=epoch)
    
    data = {
        'T': loss_logger.train.timeline,
        'Loss': loss_logger.train.history
    }
    export_pickle(data, os.path.join(log_path, "loss.equ"))

    # save the model
    coach.save(info_path)

    # final evaluation
    evaluate(trainloader, prefix='Train', epoch=opts.epochs)
    loss = evaluate(validloader, prefix="Valid", epoch=opts.epochs)
    coach.check_best(loss, info_path, epoch=opts.epochs) 

    X, Y, pred = visual(coach.model, validloader, info_path, log_path, epoch=opts.epochs)
    data = {
        'X': X,
        'Y': Y,
        'pred': pred
    }
    export_pickle(data, os.path.join(log_path, "preds.equ"))

    loss_logger.plotter.plot()
    loss_logger.plotter.save(log_path)


if __name__ ==  "__main__":
    from src.utils import readme
    cfg = load_cfg()
    opts.log_path = cfg.log_path
    readme(cfg.info_path, opts)
    readme(cfg.log_path, opts, mode="a")

    main(**cfg)

