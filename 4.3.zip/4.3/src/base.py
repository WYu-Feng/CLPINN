


from typing import Callable, Dict, Iterable
import torch
import torch.nn as nn
import os

from .utils import AverageMeter, ProgressMeter, timemeter, getLogger
from .loss_zoo import mse_loss
from .config import DEVICE, SAVED_FILENAME, PRE_BEST


class Coach:
    
    def __init__(
        self, model: nn.Module,
        loss_func: Callable, 
        equ: Callable,
        optimizer: torch.optim.Optimizer, 
        learning_policy: "learning rate policy",
        device: torch.device = DEVICE,
    ):
        self.model = model
        self.device = device
        self.loss_func = loss_func
        self.equ = equ
        self.optimizer = optimizer
        self.learning_policy = learning_policy
        self.loss = AverageMeter("Loss")
        self.progress = ProgressMeter(self.loss)

        self._best = float('inf')

   
    def save_best(self, mse: float, path: str, prefix: str = PRE_BEST):
        if mse < self._best:
            self._best = mse
            self.save(path, '_'.join((prefix, SAVED_FILENAME)))
            return 1
        else:
            return 0

    def check_best(
        self, mse: float,
        path: str, epoch: int = 8888
    ):
        logger = getLogger()
        if self.save_best(mse, path):
            logger.debug(f"[Coach] Saving the best nat ({mse:.6f}) model at epoch [{epoch}]")
        
    def save(self, path: str, filename: str = SAVED_FILENAME) -> None:
        torch.save(self.model.state_dict(), os.path.join(path, filename))

    def bc_values(self, x: torch.Tensor) -> torch.Tensor:
        x, y = x[:, 0], x[:, 1]
        return torch.where((y == 0) | ((x == 0) & (y < 1 / 5)), torch.ones_like(x), torch.zeros_like(x))

    @timemeter("Train/Epoch")
    def train(
        self, 
        trainloader: Iterable,
        boundary: Dict,
        leverage: float,
        *, epoch: int = 8888
    ) -> float:

        self.progress.step() # reset the meter
        self.model.train()
        for data in trainloader:
            x = data[0].to(self.device)

            target = 0.
            x.requires_grad_(True)
            u = self.model(x)
            g1 = torch.autograd.grad(
                u, x, 
                grad_outputs=torch.ones_like(u),
                create_graph=True
            )[0]
            ux, uy = g1[:, 0], g1[:, 1]
            uxx = torch.autograd.grad(
                ux, x, grad_outputs=torch.ones_like(ux), create_graph=True
            )[0][:, 0]
            uyy = torch.autograd.grad(
                uy, x, grad_outputs=torch.ones_like(uy), create_graph=True
            )[0][:, 1]
            x.requires_grad_(False)
            pred = self.equ(x, u, ux, uy, uxx, uyy)
            loss = self.loss_func(pred, target, reduction='mean')

            bx = next(boundary).to(self.device)
            bu = self.model(bx)
            bloss = mse_loss(bu, self.bc_values(bx))
            loss = loss + bloss * leverage
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            self.loss.update(loss.item(), x.size(0), mode="mean")

        self.progress.display(epoch=epoch) 
        self.learning_policy.step() # update the learning rate
        return self.loss.avg
    
    @timemeter("Evaluation")
    def evaluate(self, validloader: Iterable, *, epoch: int = 8888):

        self.progress.step() # reset the meter
        self.model.eval()
        for data in validloader:
            x = data[0].to(self.device)

            target = 0.
            x.requires_grad_(True)
            u = self.model(x)
            g1 = torch.autograd.grad(
                u, x, 
                grad_outputs=torch.ones_like(u),
                create_graph=True
            )[0]
            ux, uy = g1[:, 0], g1[:, 1]
            uxx = torch.autograd.grad(
                ux, x, grad_outputs=torch.ones_like(ux), create_graph=True
            )[0][:, 0]
            uyy = torch.autograd.grad(
                uy, x, grad_outputs=torch.ones_like(uy), create_graph=True
            )[0][:, 1]
            x.requires_grad_(False)
            pred = self.equ(x, u, ux, uy, uxx, uyy)
            loss = self.loss_func(pred, target, reduction='mean')


            self.loss.update(loss.item(), x.size(0), mode="mean")

        # self.progress.display(epoch=epoch) 

        return self.loss.avg