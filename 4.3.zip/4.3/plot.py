

# %%
import numpy as np
import torch
from freeplot.base import FreePlot
from freeplot.utils import import_pickle
# %%



# %%

def relative_error(x, y):
    x = x[y > 1e-6]
    y = y[y > 1e-6]
    return np.mean(np.abs((x - y)) / np.abs(y))

def mean_square_error(x, y):
    return np.mean((x - y) ** 2)

def mean_abs_error(x, y):
    return np.mean(np.abs(x - y))

# %%


# solution curve

losses = ['identity', 'refine', 'tanh']
epses = ['1e-3', '1e-6', '1e-9']

legends = {
    'exact': 'Exact solution',
    'identity': r"$r^2$",
    'log': r"$\log (r^2 + 1)$",
    'refine': r"$-\frac{1}{r^2 + 1} + 1$",
    'tanh': r"$\tanh(r^2)$"
}

fp = FreePlot((3, 3), (8, 6.2), latex=True)
for i, loss in enumerate(losses):
    for j, eps in enumerate(epses):
        file_ = f"./logs/{loss}-{eps}/preds.equ"
        # fp = FreePlot(figsize=(2.7, 2), dpi=300)
        data = import_pickle(file_)
        X, Y, Z = data['X'], data['Y'], data['pred']
        Z = np.reshape(Z, (100, 100))
        fp.contourf(X, Y, Z, index=(i, j), cmap=None)
    fp.set_label(legends[loss], index=(i, 0), axis='y')
    
fp.set(index=(0, 0), title=r"$\epsilon=10^{-3}$")
fp.set(index=(0, 1), title=r"$\epsilon=10^{-6}$")
fp.set(index=(0, 2), title=r"$\epsilon=10^{-9}$")

fp.savefig(f"./pics/4.3_solution.pdf")
# %%

# absolut error

losses = ['identity', 'log', 'refine', 'tanh']
epses = ['1e-3', '1e-6', '1e-9']

for loss in losses:
    for eps in epses:
        file_ = f"./logs/{loss}-{eps}/preds.equ"
        fp = FreePlot(figsize=(2.7, 2), dpi=300)
        # fp = FreePlot(figsize=(2.7, 2), latex=True)
        data = import_pickle(file_)
        X, Y = data['X'], data['Y']
        Z = np.abs(data['pred'] - data['target'])
        Z = np.reshape(Z, (100, 100))
        fp.contourf(X, Y, Z, cmap=None)
        fp.set_label('x', axis='x')
        fp.set_label('y', axis='y')
        fp.savefig(f"./pics/abs_error-{loss}-{eps}.png")


# %%

# loss curve

wrappers = ['identity', 'refine', 'tanh']
epss = ['1e-3', '1e-6', '1e-9']
labels = {
    'identity': r"$r^2$",
    'tanh': r"$\tanh(r^2)$",
    'log': r"$\log(r^2 + 1)$",
    'refine': r"$-\frac{1}{r^2 + 1} + 1$",
}



titles=(r"$\epsilon = 10^{-3}$", r"$\epsilon = 10^{-6}$", r"$\epsilon = 10^{-9}$", r"$\epsilon = 10^{-3}$", r"$\epsilon = 10^{-6}$", r"$\epsilon = 10^{-9}$")
fp = FreePlot((1, 3), (7.2, 2), latex=True)
for i, eps in enumerate(epss):
    flag = True
    for wrapper, colors in zip(wrappers, fp.colors[1:]):
        data = import_pickle(f"./logs/{wrapper}-{eps}/loss.equ")
        T, loss = data['T'], data['Loss']
        T = np.array(T) * 50

        fp.lineplot(T, loss, index=(0, i), marker='', label=legends[wrapper], color=colors)

    fp.set_label('Iterations', index=(0, i), axis='x')
    fp.ticklabel_format(index=(0, i), axis='x')
    fp.set(index=(0, i), title=titles[i])
    # fp.set_lim((-0.001, 0.01), index=(0, i))


fp.set_label('Training loss', index=(0, 0), axis='y')
fp.legend(0.4, 0.98, 4)
# fp.set_title()
fp.show(tight_layout=False)
fp.savefig("./test.pdf", tight_layout=False)



# %%
