
## 2022-09-20-08:26:47 


|  Attribute   |   Value   |
| :-------------: | :-----------: |
|  batch_size  |   1000    |
|  benchmark  |   False    |
|  beta1  |   0.9    |
|  beta2  |   0.999    |
|  dataset  |   shockwave    |
|  description  |   Equation=identity-1e-09    |
|  dim_latent  |   20    |
|  epochs  |   1000    |
|  eps  |   1e-09    |
|  eval_freq  |   100    |
|  eval_train  |   False    |
|  eval_valid  |   True    |
|  info_path  |   None    |
|  learning_policy  |   null    |
|  leverage  |   1.0    |
|  log2console  |   True    |
|  log2file  |   True    |
|  log_path  |   ./logs/Equation/shockwave-linear/Equation=identity-1e-09-092008    |
|  loss  |   identity    |
|  lr  |   0.001    |
|  model  |   linear    |
|  momentum  |   0.9    |
|  nums  |   1000000    |
|  nums_boundary  |   10000    |
|  nums_valid  |   100    |
|  optimizer  |   adam    |
|  progress  |   False    |
|  resume  |   False    |
|  seed  |   1    |
|  transform  |   default    |
|  weight_decay  |   0.0    |
