
## 2022-09-19-20:46:58 


|  Attribute   |   Value   |
| :-------------: | :-----------: |
|  batch_size  |   1000    |
|  benchmark  |   False    |
|  beta1  |   0.9    |
|  beta2  |   0.999    |
|  dataset  |   shockwave    |
|  description  |   Equation=identity-0.001    |
|  dim_latent  |   20    |
|  epochs  |   1000    |
|  eps  |   0.001    |
|  eval_freq  |   100    |
|  eval_train  |   False    |
|  eval_valid  |   True    |
|  info_path  |   None    |
|  learning_policy  |   null    |
|  leverage  |   1.0    |
|  log2console  |   True    |
|  log2file  |   True    |
|  log_path  |   ./logs/Equation/shockwave-linear/Equation=identity-0.001-091920    |
|  loss  |   identity    |
|  lr  |   0.001    |
|  model  |   linear    |
|  momentum  |   0.9    |
|  nums  |   1000000    |
|  nums_boundary  |   10000    |
|  nums_valid  |   100    |
|  optimizer  |   adam    |
|  progress  |   False    |
|  resume  |   False    |
|  seed  |   1    |
|  transform  |   default    |
|  weight_decay  |   0.0    |
