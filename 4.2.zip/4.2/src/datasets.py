

from typing import Callable, Optional, Tuple, List, Any
import torch
from torch.utils.data import Dataset
import torchvision.transforms as T


from .utils import getLogger
from .config import ROOT




class ShockWave(Dataset):

    def __init__(self, sampling_fn, collect_fn, num_samples, density_point, if_density_point = False, train=True):
        super().__init__()

        self.sampling_fn = sampling_fn
        self.collect_fn = collect_fn
        self.num_samples = num_samples
        self.density_point = density_point
        self.if_density_point = if_density_point
        self.data = None
        if train:
            self.sampling(num_samples)
        else:
            self.valid_sampling(num_samples)
            self.num_samples **= 2

    def sampling(self, nums: int, step: int = 100):
        if self.if_density_point:
            while nums > 0:
                cur = min(nums, step)
                x = self.sampling_fn(cur, self.density_point)
                data = self.collect_fn(x)
                if self.data is None:
                    self.data = data
                else:
                    for i in range(len(data)):
                        self.data[i] = torch.cat([self.data[i], data[i]], dim=0)
                nums -= step
        else:
            while nums > 0:
                cur = min(nums, step)
                x = self.sampling_fn(cur)
                data = self.collect_fn(x)
                if self.data is None:
                    self.data = data
                else:
                    for i in range(len(data)):
                        self.data[i] = torch.cat([self.data[i], data[i]], dim=0)
                nums -= step

                
    def valid_sampling(self, nums: int, step: int=100):
        X, Y = self.sampling_fn(nums)
        x = torch.stack([X.flatten(), Y.flatten()], dim=1)
        nums = len(x)
        cur = 0
        while nums > 0:
            data = self.collect_fn(x[cur:cur+step])
            if self.data is None:
                self.data = data
            else:
                for i in range(len(data)):
                    self.data[i] = torch.cat([self.data[i], data[i]], dim=0)
            cur += step
            nums -= step

    
    def __len__(self) -> int:
        return self.num_samples

    def __getitem__(self, index: int):
        return [item[index] for item in self.data]




class IdentityTransform:

    def __call__(self, x: Any) -> Any:
        return x

class OrderTransform:

    def __init__(self, transforms: List) -> None:
        self.transforms = transforms

    def __call__(self, data: Tuple) -> List:
        return [transform(item) for item, transform in zip(data, self.transforms)]



class WrapperSet(Dataset):

    def __init__(
        self, dataset: Dataset,
        transforms: Optional[str] = None
    ) -> None:
        """
        Args:
            dataset: dataset;
            transforms: string spilt by ',', such as "tensor,none'
        """
        super().__init__()

        self.data = dataset

        try:
            counts = len(self.data[0])
        except IndexError:
            getLogger().info("[Dataset] zero-size dataset, skip ...")
            return

        if transforms is None:
            transforms = ['none'] * counts
        else:
            transforms = transforms.split(',')
        self.transforms = [AUGMENTATIONS[transform] for transform in transforms]
        if counts == 1:
            self.transforms = self.transforms[0]
        else:
            self.transforms = OrderTransform(self.transforms)
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, index: int):
        data = self.data[index]
        return self.transforms(data)


AUGMENTATIONS = {
    'none' : IdentityTransform(),
    'tensor': T.ToTensor(),
    'cifar': T.Compose((
            T.Pad(4, padding_mode='reflect'),
            T.RandomCrop(32),
            T.RandomHorizontalFlip(),
            T.ToTensor()
        )),
}

