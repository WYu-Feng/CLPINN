from typing import Callable, Dict, Iterable
import torch
import torch.nn as nn
import os

from .utils import AverageMeter, ProgressMeter, timemeter, getLogger
from .loss_zoo import mse_loss
from .config import DEVICE, SAVED_FILENAME, PRE_BEST
import numpy as np
import copy

class Coach:
    
    def __init__(
        self, model: nn.Module,
        loss_func: Callable, 
        equ: Callable,
        optimizer: torch.optim.Optimizer, 
        learning_policy: "learning rate policy",
        device: torch.device = DEVICE,
    ):
        self.model = model
        self.device = device
        self.loss_func = loss_func
        self.equ = equ
        self.optimizer = optimizer
        self.learning_policy = learning_policy
        self.loss = AverageMeter("Loss")
        self.progress = ProgressMeter(self.loss)

        self._best = float('inf')

   
    def save_best(self, mse: float, path: str, prefix: str = PRE_BEST):
        if mse < self._best:
            self._best = mse
            self.save(path, '_'.join((prefix, SAVED_FILENAME)))
            return 1
        else:
            return 0
        
    def check_best(
        self, mse: float,
        path: str, epoch: int = 8888
    ):
        logger = getLogger()
        if self.save_best(mse, path):
            logger.debug(f"[Coach] Saving the best nat ({mse:.6f}) model at epoch [{epoch}]")
        
    def save(self, path, epoch):
        torch.save(self.model.state_dict(), os.path.join(path, '{:}_'.format(epoch) + SAVED_FILENAME))

        
    def get_T(self, validloader, opts):
        ## 同时获得截断点对应的x, 用于后续加密
        loss_function = nn.MSELoss(reduction='none')
        for i, data in enumerate(validloader):
            x, u, ux, uy, uxx, uyy = [item.to(self.device) for item in data]
            target = self.equ(x, u, ux, uy, uxx, uyy)
            x.requires_grad_(True)
            u = self.model(x)
            g1 = torch.autograd.grad(
                u, x, 
                grad_outputs=torch.ones_like(u),
                create_graph=True
            )[0]
            ux, uy = g1[:, 0], g1[:, 1]
            uxx = torch.autograd.grad(
                ux, x, grad_outputs=torch.ones_like(ux), create_graph=True
            )[0][:, 0]
            uyy = torch.autograd.grad(
                uy, x, grad_outputs=torch.ones_like(uy), create_graph=True
            )[0][:, 1]
            x.requires_grad_(False)
            pred = self.equ(x, u, ux, uy, uxx, uyy)
            loss = loss_function(pred, target)
            loss_view = loss.view(opts.nums_test, opts.nums_test).detach().cpu().numpy()
            x_view = x.view(opts.nums_test, opts.nums_test, x.shape[-1]).detach().cpu().numpy()
            
        loss_list = list()
        point_list = list()
        h_dis = 1 / opts.nums_test
        o_dis = 2**0.5 / opts.nums_test
        
        for n in range(opts.nums_test - 1):
            for m in range(opts.nums_test - 1):
                if abs(loss_view[n,m] - loss_view[n,m+1]) / h_dis < opts.L \
                and abs(loss_view[n,m] - loss_view[n+1,m]) / h_dis < opts.L \
                and abs(loss_view[n,m] - loss_view[n+1,m+1]) / o_dis < opts.L:
                    loss_list.append(loss_view[n, m])
                else:
                    point_list.append(x_view[n, m])
        
        return max(loss_list), point_list
    
    
    @timemeter("Train/Epoch")
    def train(
        self, 
        trainloader,
        boundary, t_list, leverage, opts, epoch = 8888):

        self.model.train()
        for i, data in enumerate(trainloader):
            x, u0, ux, uy, uxx, uyy = [item.to(self.device) for item in data]
            target = self.equ(x, u0, ux, uy, uxx, uyy)
            x.requires_grad_(True)
            u = self.model(x)
            g1 = torch.autograd.grad(
                u, x, 
                grad_outputs=torch.ones_like(u),
                create_graph=True
            )[0]
            ux, uy = g1[:, 0], g1[:, 1]
            uxx = torch.autograd.grad(
                ux, x, grad_outputs=torch.ones_like(ux), create_graph=True
            )[0][:, 0]
            uyy = torch.autograd.grad(
                uy, x, grad_outputs=torch.ones_like(uy), create_graph=True
            )[0][:, 1]
            x.requires_grad_(False)
            pred = self.equ(x, u, ux, uy, uxx, uyy)
            
            u_loss = self.loss_func(u, u0, reduction='mean')
            loss = self.loss_func(pred, target, reduction='none')
            loss_ori = torch.mean(loss).cpu().detach().numpy()
            loss = torch.mean(torch.min(loss, t_list))
            
            bx = boundary.to(self.device)
            bu = self.model(bx)
            bloss = mse_loss(bu, torch.zeros_like(bu))
            loss = loss + bloss
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            if i % 200 == 0:
                with open('eps_{:}_train_loss.txt'.format(opts.eps), 'a') as f:
                    f.write(str(loss_ori + bloss))
                    f.write('\n')  
        return self.loss.avg
