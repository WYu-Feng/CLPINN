#!/usr/bin/env python


from typing import Tuple
import argparse

from src.loadopts import *
from src.utils import timemeter
from src.config import DEVICE
import torch.nn as nn


METHOD = "Equation"
SAVE_FREQ = 5
FMT = "{description}={leverage}-{eps}-{nums}" \
        "={learning_policy}-{optimizer}-{lr}" \
        "={epochs}" \
        "={batch_size}={transform}"

parser = argparse.ArgumentParser()
parser.add_argument("--model", type=str, default='linear')
parser.add_argument("--dataset", type=str, default='shockwave')
parser.add_argument("--info_path", type=str, default=None)

# for the shockwave dataset
parser.add_argument("--eps", type=float, default=1e-9)
parser.add_argument("--nums", type=int, default=5000)
parser.add_argument("--nums-valid", type=int, default=100, help="nums ** 2")
parser.add_argument("--nums-test", type=int, default=100, help="nums ** 2")
parser.add_argument("--nums-boundary", type=int, default=100)
parser.add_argument("--L", type=int, default = 100)

# for expnet
parser.add_argument("--dim-latent", type=int, default=20)

# for regularization
parser.add_argument("--leverage", type=float, default=1.)

# basic settings
parser.add_argument("--loss", type=str, default="mse_loss")
parser.add_argument("--optimizer", type=str, choices=("sgd", "adam"), default="adam")
parser.add_argument("-mom", "--momentum", type=float, default=0.9,
                help="the momentum used for SGD")
parser.add_argument("-beta1", "--beta1", type=float, default=0.9,
                help="the first beta argument for Adam")
parser.add_argument("-beta2", "--beta2", type=float, default=0.999,
                help="the second beta argument for Adam")
parser.add_argument("-wd", "--weight_decay", type=float, default=0.,
                help="weight decay")
parser.add_argument("-lr", "--lr", "--LR", "--learning_rate", type=float, default=0.01)
parser.add_argument("-lp", "--learning_policy", type=str, default="null", 
                help="learning rate schedule defined in config.py")
parser.add_argument("--epochs", type=int, default=20000)
parser.add_argument("-b", "--batch_size", type=int, default=100)
parser.add_argument("--transform", type=str, default='default', 
                help="the data augmentations which will be applied during training.")


# eval
parser.add_argument("--eval-train", action="store_true", default=False)
parser.add_argument("--eval-valid", action="store_false", default=True)
parser.add_argument("--eval-freq", type=int, default=100,
                help="for valid dataset only")

parser.add_argument("--resume", action="store_true", default=False)
parser.add_argument("--progress", action="store_true", default=False, 
                help="show the progress if true")
parser.add_argument("--log2file", action="store_false", default=True,
                help="False: remove file handler")
parser.add_argument("--log2console", action="store_false", default=True,
                help="False: remove console handler if log2file is True ...")
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--benchmark", action="store_true", default=False)
parser.add_argument("-m", "--description", type=str, default=METHOD)
opts = parser.parse_args()
opts.description = FMT.format(**opts.__dict__)


import torch
import numpy as np
import math
from scipy.stats import uniform


def equ(x, u, ux, uy, uxx, uyy, eps=opts.eps):
    x, y = x[:, 0], x[:, 1]
    return -eps * (uxx + uyy) + (3 - x - y) * ux + 1.5 * u


def oracle(x: torch.Tensor, eps=opts.eps):
    x, y = x[:, 0], x[:, 1]
    return (torch.sin(math.pi * x / 2) - ((1 - x).div(eps).neg().exp() - math.exp(-1 / eps)).div(1 - math.exp(-1 / eps))) \
        * (1 - y.neg().div(math.sqrt(eps)).exp()) * (1 - (1 - y).neg().div(math.sqrt(eps)).exp()) / (1 - math.exp(-1 / math.sqrt(eps)))


def sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    x = uniform.rvs(loc=bounds[0], scale=bounds[1] - bounds[0], size=nums).astype(np.float32)
    y = uniform.rvs(loc=bounds[0], scale=bounds[1] - bounds[0], size=nums).astype(np.float32)
    x, y = torch.from_numpy(x), torch.from_numpy(y)
    return torch.stack([x, y], dim=1)


def valid_sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    meta = torch.linspace(bounds[0], bounds[1], steps=nums)
    X, Y = torch.meshgrid(meta, meta)
    return X, Y


# def density_sampling_fn(nums, density_point, scope = 0.1):
#     x = torch.linspace(max(density_point[0] - scope/2, 1e-5), min(density_point[0] + scope/2, 1 - 1e-5), steps = nums)
#     idx = torch.randperm(x.nelement())
#     x = x.view(-1)[idx].view(x.size())
    
#     y = torch.linspace(max(density_point[1] - scope/2, 1e-5), min(density_point[1] + scope/2, 1 - 1e-5), steps = nums)
#     idx = torch.randperm(y.nelement())
#     y = y.view(-1)[idx].view(y.size())

#     return torch.stack([x, y], dim=1)


def density_sampling_fn(nums, density_points, scope = 0.01):
    import random
    add_point = list()
    while len(add_point) < nums:
        idx = random.randint(0, len(density_points) - 1)
        point = density_points[idx]
        x = np.clip(point[0] + random.uniform(-scope, scope), 0, 1)
        y = np.clip(point[1] + random.uniform(-scope, scope), 0, 1)
        add_point.append([x, y])

    add_point = torch.tensor(add_point).to(torch.float32)
    return add_point


def bd_sampling_fn(nums: int, bounds: Tuple[float] = (0, 1)):
    x = torch.linspace(bounds[0], bounds[1], steps=nums)
    y = torch.zeros_like(x)
    data = []
    for line in ([x, y], [y, x], [x, y + 1], [y + 1, x]):
        data.append(torch.stack(line, dim=1))
    return torch.cat(data, dim=0)


def collect_fn(data: torch.Tensor): # not for dataloader
    x = data.clone()
    x.requires_grad_(True)
    z = oracle(x)
    g1 = torch.autograd.grad(
        z, x, grad_outputs=torch.ones_like(z), create_graph=True
    )[0]
    ux, uy = g1[:, 0], g1[:, 1]
    uxx = torch.autograd.grad(
        ux, x, grad_outputs=torch.ones_like(ux), retain_graph=True
    )[0][:, 0]
    uyy = torch.autograd.grad(
        uy, x, grad_outputs=torch.ones_like(uy), retain_graph=False
    )[0][:, 1]
    return [data, z.detach(), ux.detach(), uy.detach(), uxx.detach(), uyy.detach()]


@timemeter("Setup")
def load_cfg() -> Tuple[Config, str]:
    from src.dict2obj import Config
    from src.base import Coach
    from src.utils import set_seed, activate_benchmark, load_checkpoint, set_logger, load
    from models.base import EquArch

    cfg = Config()
    
    # generate the path for logging information and saving parameters
    cfg['info_path'], cfg['log_path'] = generate_path(
        method=METHOD, dataset_type=opts.dataset, 
        model=opts.model, description=opts.description
    )
    # set logger
    logger = set_logger(
        path=cfg.log_path, 
        log2file=opts.log2file, 
        log2console=opts.log2console
    )

    activate_benchmark(opts.benchmark)
    set_seed(opts.seed)

    # the model and other settings for training
    model = load_model(opts.model)(
        latent_features=opts.dim_latent
    )
    model = EquArch(model=model)
    # load(model, '')
    
    if opts.info_path is not None:
        load(
            model, opts.info_path
        )

    # load the dataset
    cfg['trainset'] = load_dataset(
        dataset_type=opts.dataset,
        sampling_fn=sampling_fn,
        collect_fn=collect_fn,
        num_samples=opts.nums,
        train=True
    )
    
    validset = load_dataset(
        dataset_type=opts.dataset,
        sampling_fn=valid_sampling_fn,
        collect_fn=collect_fn,
        num_samples=opts.nums_valid,
        train=False
    )
    # cfg['trainloader'] = load_dataloader(
    #     dataset=trainset,
    #     batch_size=opts.batch_size,
    #     train=True,
    #     show_progress=opts.progress
    # )
    cfg['validloader'] = load_dataloader(
        dataset=validset,
        batch_size = opts.nums_valid * opts.nums_valid,
        train=False,
        show_progress=opts.progress
    )

    cfg['boundary'] = bd_sampling_fn(opts.nums_boundary)

    # load the optimizer and learning_policy
    optimizer = load_optimizer(
        model=model, optim_type=opts.optimizer, lr=opts.lr,
        momentum=opts.momentum, betas=(opts.beta1, opts.beta2),
        weight_decay=opts.weight_decay
    )
    learning_policy = load_learning_policy(
        optimizer=optimizer, 
        learning_policy_type=opts.learning_policy,
        T_max=opts.epochs
    )

    if opts.resume:
        cfg['start_epoch'] = load_checkpoint(
            path=cfg.info_path, model=model, 
            optimizer=optimizer, 
            lr_scheduler=learning_policy
        )
    else:
        cfg['start_epoch'] = 0

    cfg['coach'] = Coach(
        model=model,
        loss_func=load_loss_func(opts.loss), 
        equ=equ,
        optimizer=optimizer,
        learning_policy=learning_policy
    )

    return cfg


def preparation(coach):
    from src.utils import TrackMeter, ImageMeter, getLogger
    from src.dict2obj import Config
    logger = getLogger()
    loss_logger = Config(
        train=TrackMeter("Train"),
        valid=TrackMeter("Valid")
    )

    loss_logger.plotter = ImageMeter(*loss_logger.values(), title="Loss")

    @timemeter("Evaluation")
    def evaluate(dataloader, prefix='Valid', epoch=8888):
        loss = coach.evaluate(dataloader)
        logger.info(f"{prefix} >>> [Loss: {loss:.6f}]")
        getattr(loss_logger, prefix.lower())(data=loss, T=epoch)
        return loss
    return loss_logger, evaluate



def visual(model, visualloader, info_path, log_path, device=DEVICE, epoch=8888):
    import os
    import numpy as np
    import math
    from mpl_toolkits.mplot3d import Axes3D
    import matplotlib.pyplot as plt
    from matplotlib import cm
    from matplotlib.ticker import LinearLocator, FormatStrFormatter
    
    model.eval()
    running_results = {
        'x':[], 'target':[], 'pred': []
    }

    if not os.path.exists('pred img'):
        os.makedirs('pred img')

    if not os.path.exists('loss img'):
        os.makedirs('loss img')
    
    for x, u, ux, uy, uxx, uyy in visualloader:
        x, u = x.to(device), u.to(device)
        u_pred = model(x)
        running_results['x'].append(x.detach().cpu())
        running_results['target'].append(u.detach().cpu())
        running_results['pred'].append(u_pred.detach().cpu())
    
    for key, value in running_results.items():
        running_results[key] = torch.cat(value, dim=0).numpy()
        
    X = running_results['x'][:, 0]
    Y = running_results['x'][:, 1]
    
    X = X.reshape((opts.nums_valid, opts.nums_valid))
    Y = Y.reshape((opts.nums_valid, opts.nums_valid))
    
    Z_real = running_results['target']
    Z_pred = running_results['pred']
    Z_loss = np.abs(running_results['pred'] - running_results['target'])
    
    Z_real = Z_real.reshape((opts.nums_valid, opts.nums_valid))
    Z_pred = Z_pred.reshape((opts.nums_valid, opts.nums_valid))
    Z_loss = Z_loss.reshape((opts.nums_valid, opts.nums_valid))
    
    
    # fig = plt.figure(dpi=300)
    # ax = fig.gca(projection='3d')
    # surf = ax.plot_surface(X, Y, Z_real, cmap=cm.coolwarm, linewidth=0, antialiased=False)
    # plt.yticks(size=10)  # 设置大小及加粗
    # plt.xticks(size=10)
    # ax.tick_params(axis='z', labelsize=10)
    # plt.xlabel("$x_1$", fontsize=10, fontweight='bold')
    # plt.ylabel("$x_2$", fontsize=10, fontweight='bold')
    # ax.set_zlabel('$u(x_1, x_2)$')
    # ax.view_init(10, 225)
    # plt.savefig('real_{:}.png'.format(epoch), bbox_inches='tight', pad_inches=0)
    
    
    fig = plt.figure(dpi=300)
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(X, Y, Z_pred, cmap=cm.coolwarm, linewidth=0, antialiased=False)
    plt.yticks(size=10)  # 设置大小及加粗
    plt.xticks(size=10)
    ax.tick_params(axis='z', labelsize=10)
    plt.xlabel("$x_1$", fontsize=10, fontweight='bold')
    plt.ylabel("$x_2$", fontsize=10, fontweight='bold')
    ax.set_zlabel('$u(x_1, x_2)$')
    ax.view_init(10, 225)
    plt.savefig('./pred img/pred_{:}.png'.format(epoch), bbox_inches='tight', pad_inches=0)
    
    
    fig = plt.figure(dpi=300)
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(X, Y, Z_loss, cmap=cm.coolwarm, linewidth=0, antialiased=False)
    plt.yticks(size=10)  # 设置大小及加粗
    plt.xticks(size=10)
    ax.tick_params(axis='z', labelsize=10)
    plt.xlabel("$x_1$", fontsize=10, fontweight='bold')
    plt.ylabel("$x_2$", fontsize=10, fontweight='bold')
    ax.set_zlabel('Absolut Errors')
    ax.view_init(10, 225)
    plt.savefig('./loss img/loss_{:}.png'.format(epoch), bbox_inches='tight', pad_inches=0)
    
    
    
def test_loss(model, testloader):
    model.eval()
    mse_function = nn.MSELoss(reduction='mean')
    l1_function = nn.L1Loss(reduction='mean')
    
    ave_mse_loss = 0
    ave_l1_loss = 0
    for data in testloader:        
        x, u, ux, uy, uxx, uyy = [item.to('cuda') for item in data]
        u_pred = model(x)
        
        ave_mse_loss += mse_function(u_pred, u)
        ave_l1_loss += l1_function(u_pred, u)
        
    ave_mse_loss = ave_mse_loss / len(testloader)
    ave_l1_loss = ave_l1_loss / len(testloader)

    return ave_mse_loss, ave_l1_loss


@timemeter("Main")
def main(coach, trainset, validloader, boundary, start_epoch, info_path, log_path):  
    from src.utils import save_checkpoint
    import matplotlib.pyplot as plt
    import os
    
    # preparation
    loss_logger, evaluate = preparation(coach)
    trainset_up = trainset
    for epoch in range(start_epoch, opts.epochs):
        if epoch % 10 == 0:
            T, density_points = coach.get_T(validloader, opts)
            # T = 2.
            print('epoch={:} T={:}'.format(epoch, T))
            print('new density_point {:} num'.format(len(density_points)))
            t_list = torch.tensor([T for _ in range(opts.batch_size)]).cuda()
            
            if len(trainset_up) < 20000:
                densityset = load_dataset(
                    dataset_type=opts.dataset,
                    sampling_fn=density_sampling_fn,
                    collect_fn=collect_fn,
                    num_samples = 100,
                    density_point = density_points,
                    if_density_point = True, 
                    train=True)
                trainset_up = trainset_up + densityset

                trainloader = load_dataloader(
                    dataset = trainset_up,
                    batch_size = opts.batch_size,
                    train = True,
                    show_progress = opts.progress)
        
        running_loss = coach.train(trainloader, boundary, t_list = t_list, leverage=opts.leverage, epoch=epoch, opts = opts)
   
        if (epoch + 1) % 100 == 0:
            visual(coach.model, validloader, info_path, log_path, coach.device, epoch)
            
            ## 采样点可视化
            if not os.path.exists('sample img'):
                os.makedirs('sample img')
            x1, x2 = list(), list()
            for x, _, _, _, _, _ in trainloader:
                x1.append(x.numpy()[:, 0])
                x2.append(x.numpy()[:, 1])
            fig, ax = plt.subplots()
            ax.scatter(x1, x2, c = 'red', label = 'Sample points', s = 16, alpha=0.1)
            ax.legend()
            plt.xlabel("$x_1$")
            plt.ylabel("$x_2$")
            plt.savefig('./sample img/sample_{:}.png'.format(epoch), bbox_inches='tight', pad_inches=0)
    
        # save the model
        if (epoch+1) % 100 == 0:
            coach.save(info_path, epoch)


if __name__ ==  "__main__":
    from src.utils import readme
    eps_list = [1e-9]
    for eps in eps_list:
        opts.eps = eps
        
        cfg = load_cfg()
        opts.log_path = cfg.log_path
        readme(cfg.info_path, opts)
        readme(cfg.log_path, opts, mode="a")

        main(**cfg)

