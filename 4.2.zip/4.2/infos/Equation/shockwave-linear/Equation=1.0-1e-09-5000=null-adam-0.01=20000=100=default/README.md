
## 2022-09-28-09:09:21 


|  Attribute   |   Value   |
| :-------------: | :-----------: |
|  L  |   50    |
|  batch_size  |   100    |
|  benchmark  |   False    |
|  beta1  |   0.9    |
|  beta2  |   0.999    |
|  dataset  |   shockwave    |
|  description  |   Equation=1.0-1e-09-5000=null-adam-0.01=20000=100=default    |
|  dim_latent  |   20    |
|  epochs  |   20000    |
|  eps  |   1e-09    |
|  eval_freq  |   100    |
|  eval_train  |   False    |
|  eval_valid  |   True    |
|  info_path  |   None    |
|  learning_policy  |   null    |
|  leverage  |   1.0    |
|  log2console  |   True    |
|  log2file  |   True    |
|  log_path  |   ./logs/Equation/shockwave-linear/Equation=1.0-1e-09-5000=null-adam-0.01=20000=100=default-092809    |
|  loss  |   mse_loss    |
|  lr  |   0.01    |
|  model  |   linear    |
|  momentum  |   0.9    |
|  nums  |   5000    |
|  nums_boundary  |   100    |
|  nums_test  |   100    |
|  nums_valid  |   100    |
|  optimizer  |   adam    |
|  progress  |   False    |
|  resume  |   False    |
|  seed  |   1    |
|  transform  |   default    |
|  weight_decay  |   0.0    |
