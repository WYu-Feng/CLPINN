

import torch
import torch.nn as nn
from .layerops import Linear


class LinearNet(nn.Module):

    def __init__(
        self, 
        in_features: int = 2,
        latent_features: int = 20,
    ) -> None:
        super().__init__()

       
        self.act = nn.Tanh()
#         self.dense = nn.Sequential(
#             Linear(in_features, latent_features),
#             self.act,
#             Linear(latent_features, latent_features),
#             self.act,
#         )
        
        self.linear1 = Linear(in_features, latent_features)
        self.linear2 = Linear(latent_features, latent_features)
        self.linear3 = Linear(latent_features, 1)
        
        
#         torch.nn.init.constant_(self.linear.weight, 0)
#         torch.nn.init.constant_(self.linear.bias, 0)

#         torch.nn.init.normal_(self.linear1.weight, mean=0, std=1)
#         torch.nn.init.normal_(self.linear1.bias, mean=0, std=1)
        
#         torch.nn.init.normal_(self.linear2.weight, mean=0, std=1)
#         torch.nn.init.normal_(self.linear2.bias, mean=0, std=1)

#         torch.nn.init.normal_(self.linear3.weight, mean=0, std=1)
#         torch.nn.init.normal_(self.linear3.bias, mean=0, std=1)
        
        nn.init.uniform_(self.linear1.weight, -0.5, 0.5)
        nn.init.uniform_(self.linear1.bias, -0.5, 0.5)
        nn.init.uniform_(self.linear2.weight, -0.5, 0.5)
        nn.init.uniform_(self.linear2.bias, -0.5, 0.5)
        nn.init.uniform_(self.linear3.weight, -0.5, 0.5)
        nn.init.uniform_(self.linear3.bias, -0.5, 0.5)

    def forward(self, x):
        return self.linear3(self.act(self.linear2(self.act(self.linear1(x))))).squeeze()

